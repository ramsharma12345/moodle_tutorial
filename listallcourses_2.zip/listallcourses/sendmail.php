// factorial program in php?
<?php 
function factorial($n){
    if ($n <= 1) {
        return 1;
    } else {
        return $n * factorial($n - 1);
    }
}

if (isset($_GET['submit'])) {
    $n = intval($_GET["num"]);
    echo factorial($n);
}
// send email code in PHP?
<?php
    $to      = 'nobody@example.com';
    $subject = 'the subject';
    $message = 'hello';
    $headers = 'From: webmaster@example.com'       . "\r\n" .
                 'Reply-To: webmaster@example.com' . "\r\n" .
                 'X-Mailer: PHP/' . phpversion();

    mail($to, $subject, $message, $headers);
?>

]
